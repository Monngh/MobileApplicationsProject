package com.example.project.ui.screen.container

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.data.remote.RetrofitClient
import com.example.project.data.repository.AuthRepository
import com.example.project.domain.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    private val authRepository: AuthRepository = RetrofitClient.createAuthRepository()
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Checking)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Token actual (temporal - después se guardará en SharedPreferences)
    private var _authToken: String? = null
    val authToken: String? get() = _authToken

    init {
        checkAuthStatus()
    }

    /**
     * Verifica si existe una sesión guardada
     */
    fun checkAuthStatus() {
        viewModelScope.launch {
            // TODO: Leer de SharedPreferences
            kotlinx.coroutines.delay(1000)

            // Simula verificación de token
            val hasToken = false // TODO: TokenManager.hasToken()

            _authState.value = if (hasToken) {
                AuthState.Authenticated
            } else {
                AuthState.Unauthenticated
            }
        }
    }

    /**
     * Guardar sesión después de login/registro exitoso
     */
    fun onLoginSuccess(token: String, user: User) {
        viewModelScope.launch {
            // TODO: Guardar en SharedPreferences
            // TokenManager.saveToken(token)
            // TokenManager.saveUser(user)

            _authToken = token
            _currentUser.value = user
            _authState.value = AuthState.Authenticated
        }
    }

    /**
     * Cerrar sesión
     */
    fun logout() {
        viewModelScope.launch {
            // Llamar al backend
            _authToken?.let { token ->
                authRepository.logout(token)
            }

            // TODO: Limpiar SharedPreferences
            // TokenManager.clearToken()
            // TokenManager.clearUser()

            _authToken = null
            _currentUser.value = null
            _authState.value = AuthState.Unauthenticated
        }
    }

    /**
     * Verificar si el usuario está logueado
     */
    fun isLoggedIn(): Boolean {
        return _authState.value is AuthState.Authenticated
    }

    /**
     * Obtener token para otras llamadas
     */
    fun getToken(): String? {
        return _authToken
    }
}

sealed class AuthState {
    object Checking : AuthState()
    object Authenticated : AuthState()
    object Unauthenticated : AuthState()
}
