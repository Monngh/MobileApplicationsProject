package com.example.project.ui.screen.pages

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.project.ui.components.PropertyCard
import com.example.project.ui.screen.pages.home.HomeViewModel
import com.example.project.ui.screen.pages.home.PropertyItem
import com.example.project.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomePage(
    paddingValues: PaddingValues,
    onNavigateToPropertyDetail: (String) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(paddingValues)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(Dimens.SpacerMedium)
        ) {
            // Barra de búsqueda mejorada
            item {
                SearchBarSection(
                    searchText = uiState.searchText,
                    onSearchTextChanged = viewModel::onSearchTextChanged
                )
            }

            // Categorías con scroll horizontal
            item {
                CategoriesSection(
                    selectedCategory = uiState.selectedCategory,
                    onCategorySelected = viewModel::onCategorySelected
                )
            }

            // Propiedades destacadas
            if (uiState.featured.isNotEmpty()) {
                item {
                    FeaturedSection(
                        properties = uiState.featured,
                        onPropertyClick = onNavigateToPropertyDetail,
                        onFavoriteClick = viewModel::toggleFavorite
                    )
                }
            }

            // Título de todas las propiedades
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Dimens.PaddingMedium),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Todas las Propiedades",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${uiState.properties.size} resultados",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            // Grid de propiedades
            item {
                PropertyGridSection(
                    properties = uiState.properties,
                    onPropertyClick = onNavigateToPropertyDetail,
                    onFavoriteClick = viewModel::toggleFavorite
                )
            }
        }

        // Estado de carga
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(60.dp),
                    strokeWidth = 6.dp,
                    color = UptelBlue
                )
            }
        }

        // Estado de error
        uiState.error?.let { error ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(Dimens.PaddingMedium),
                action = {
                    TextButton(onClick = { viewModel.loadProperties() }) {
                        Text("Reintentar")
                    }
                }
            ) {
                Text(error)
            }
        }
    }
}

// ========================================
// COMPONENTES INTERNOS MEJORADOS
// ========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchBarSection(
    searchText: String,
    onSearchTextChanged: (String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.PaddingMedium, vertical = Dimens.SpacerSmall),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = "Buscar",
                tint = TextSecondary
            )

            TextField(
                value = searchText,
                onValueChange = onSearchTextChanged,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        "Buscar departamentos, casas...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true
            )

            IconButton(onClick = { /* TODO: Filtros avanzados */ }) {
                Icon(
                    Icons.Default.Tune,
                    contentDescription = "Filtros",
                    tint = UptelBlue
                )
            }
        }
    }
}

@Composable
private fun CategoriesSection(
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    val categories = listOf(
        "Todos" to Icons.Default.Home,
        "Departamentos" to Icons.Default.Apartment,
        "Casas" to Icons.Default.House,
        "Estudios" to Icons.Default.Bed,
        "Compartido" to Icons.Default.Groups
    )

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(Dimens.SpacerSmall),
        contentPadding = PaddingValues(horizontal = Dimens.PaddingMedium)
    ) {
        items(categories) { (category, icon) ->
            CategoryChip(
                label = category,
                icon = icon,
                isSelected = category == selectedCategory,
                onClick = { onCategorySelected(category) }
            )
        }
    }
}

@Composable
private fun CategoryChip(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Text(label, style = MaterialTheme.typography.labelMedium)
            }
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = UptelBlue,
            selectedLabelColor = Color.White
        )
    )
}

@Composable
private fun FeaturedSection(
    properties: List<PropertyItem>,
    onPropertyClick: (String) -> Unit,
    onFavoriteClick: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(Dimens.SpacerSmall)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.PaddingMedium),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Star,
                    contentDescription = null,
                    tint = UptelBlue,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "Destacadas",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            TextButton(onClick = { /* TODO */ }) {
                Text("Ver todas")
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(Dimens.SpacerMedium),
            contentPadding = PaddingValues(horizontal = Dimens.PaddingMedium)
        ) {
            items(properties) { property ->
                PropertyCard(
                    title = property.title,
                    location = property.location,
                    price = property.price,
                    rating = property.rating,
                    beds = property.beds,
                    baths = property.baths,
                    isVerified = property.isVerified,
                    isFavorite = property.isFavorite,
                    onClick = { onPropertyClick(property.id) },
                    onFavoriteClick = { onFavoriteClick(property.id) },
                    modifier = Modifier.width(280.dp)
                )
            }
        }
    }
}

@Composable
private fun PropertyGridSection(
    properties: List<PropertyItem>,
    onPropertyClick: (String) -> Unit,
    onFavoriteClick: (String) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
            .fillMaxWidth()
            .height(800.dp)
            .padding(horizontal = Dimens.PaddingMedium),
        horizontalArrangement = Arrangement.spacedBy(Dimens.SpacerSmall),
        verticalArrangement = Arrangement.spacedBy(Dimens.SpacerSmall)
    ) {
        items(properties) { property ->
            PropertyCard(
                title = property.title,
                location = property.location,
                price = property.price,
                rating = property.rating,
                beds = property.beds,
                baths = property.baths,
                isVerified = property.isVerified,
                isFavorite = property.isFavorite,
                onClick = { onPropertyClick(property.id) },
                onFavoriteClick = { onFavoriteClick(property.id) },
            )
        }
    }
}
