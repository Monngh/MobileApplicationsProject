package com.example.project.ui.screen.pages

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.project.ui.components.PrimaryButton
import com.example.project.ui.components.PropertyCard
import com.example.project.ui.screen.pages.saved.SavedViewModel
import com.example.project.ui.theme.*

@Composable
fun SavedScreen(
    paddingValues: PaddingValues,
    onNavigateToPropertyDetail: (String) -> Unit,
    onExploreClick: () -> Unit,
    viewModel: SavedViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Inicializar con token (obtener de AuthViewModel)
    LaunchedEffect(Unit) {
        viewModel.initialize(null) // TODO: Pasar token real
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
    ) {
        if (uiState.favorites.isEmpty() && !uiState.isLoading) {
            // Estado vacío
            EmptyFavoritesState(onExploreClick = onExploreClick)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(Dimens.SpacerMedium)
            ) {
                // Header
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = Dimens.PaddingMedium, vertical = Dimens.SpacerSmall)
                    ) {
                        Text(
                            text = "Mis Favoritos",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(Dimens.SpacerSmall))

                        Text(
                            text = "${uiState.favorites.size} propiedades guardadas",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                // Filtros por categoría
                item {
                    CategoryFilters(
                        selectedCategory = uiState.selectedCategory,
                        onCategorySelected = viewModel::onCategorySelected
                    )
                }

                // Lista de favoritos
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = Dimens.PaddingMedium),
                        verticalArrangement = Arrangement.spacedBy(Dimens.SpacerMedium)
                    ) {
                        uiState.favorites.forEach { property ->
                            PropertyCard(
                                title = property.title,
                                location = property.location,
                                price = property.price,
                                rating = property.rating,
                                beds = property.beds,
                                baths = property.baths,
                                isVerified = property.isVerified,
                                isFavorite = property.isFavorite,
                                onClick = { onNavigateToPropertyDetail(property.id) },
                                onFavoriteClick = { viewModel.removeFromFavorites(property.id) }
                            )
                        }
                    }
                }
            }
        }

        // Loading
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = UptelBlue)
            }
        }

        // Error
        uiState.error?.let { error ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(Dimens.PaddingMedium)
            ) {
                Text(error)
            }
        }
    }
}

@Composable
private fun EmptyFavoritesState(onExploreClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(Dimens.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Outlined.FavoriteBorder,
            contentDescription = null,
            modifier = Modifier.size(120.dp),
            tint = TextSecondary
        )

        Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

        Text(
            text = "No tienes favoritos aún",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(Dimens.SpacerSmall))

        Text(
            text = "Explora propiedades y guarda tus favoritas para verlas después",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

        PrimaryButton(
            text = "Explorar Propiedades",
            onClick = onExploreClick,
            modifier = Modifier.fillMaxWidth(0.7f)
        )
    }
}

@Composable
private fun CategoryFilters(
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    val categories = listOf("Todos", "Departamentos", "Casas", "Estudios")

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(Dimens.SpacerSmall),
        contentPadding = PaddingValues(horizontal = Dimens.PaddingMedium)
    ) {
        items(categories) { category ->
            FilterChip(
                selected = category == selectedCategory,
                onClick = { onCategorySelected(category) },
                label = { Text(category) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = UptelBlue,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}
