package com.example.project.ui.screen.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.data.remote.RetrofitClient
import com.example.project.data.remote.dto.PropertyDetail
import com.example.project.data.repository.FavoriteRepository
import com.example.project.data.repository.PropertyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PropertyDetailViewModel(
    private val propertyRepository: PropertyRepository = RetrofitClient.createPropertyRepository(),
    private val favoriteRepository: FavoriteRepository = RetrofitClient.createFavoriteRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(PropertyDetailUiState())
    val uiState: StateFlow<PropertyDetailUiState> = _uiState.asStateFlow()

    private var authToken: String? = null
    private var propertyId: String? = null

    fun initialize(token: String?, propertyId: String) {
        this.authToken = token
        this.propertyId = propertyId

        if (token != null) {
            loadPropertyDetail()
        } else {
            loadMockPropertyDetail()
        }
    }

    fun loadPropertyDetail() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            if (authToken != null && propertyId != null) {
                val result = propertyRepository.getPropertyDetail(authToken!!, propertyId!!)

                if (result.isSuccess) {
                    val property = result.getOrNull()!!
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        property = property
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message
                    )
                }
            } else {
                loadMockPropertyDetail()
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            val currentProperty = _uiState.value.property ?: return@launch
            val newFavoriteState = !currentProperty.isFavorite

            _uiState.value = _uiState.value.copy(
                property = currentProperty.copy(isFavorite = newFavoriteState)
            )

            // Sincronizar con API
            authToken?.let { token ->
                if (newFavoriteState) {
                    favoriteRepository.addToFavorites(token, propertyId!!)
                } else {
                    favoriteRepository.removeFromFavorites(token, propertyId!!)
                }
            }
        }
    }

    private fun loadMockPropertyDetail() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            kotlinx.coroutines.delay(1000)

            // Mock data - reemplazar con real
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                property = null // Se maneja en UI
            )
        }
    }
}

data class PropertyDetailUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val property: PropertyDetail? = null
)
