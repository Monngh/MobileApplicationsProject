package com.example.project.ui.screen.main.pages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.data.remote.RetrofitClient
import com.example.project.data.remote.dto.UserProfile
import com.example.project.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val userRepository: UserRepository = RetrofitClient.createUserRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    private var authToken: String? = null

    fun initialize(token: String?) {
        authToken = token
        if (token != null) {
            loadProfile()
        }
    }

    fun loadProfile() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            if (authToken != null) {
                val result = userRepository.getUserProfile(authToken!!)

                if (result.isSuccess) {
                    val profile = result.getOrNull()!!
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        profile = profile
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message
                    )
                }
            }
        }
    }

    fun updateProfile(name: String?, phone: String?, bio: String?) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isUpdating = true)

            if (authToken != null) {
                val result = userRepository.updateUserProfile(authToken!!, name, phone, bio)

                if (result.isSuccess) {
                    val updatedProfile = result.getOrNull()!!
                    _uiState.value = _uiState.value.copy(
                        isUpdating = false,
                        profile = updatedProfile
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isUpdating = false,
                        error = "Error al actualizar perfil"
                    )
                }
            }
        }
    }
}

data class ProfileUiState(
    val isLoading: Boolean = false,
    val isUpdating: Boolean = false,
    val error: String? = null,
    val profile: UserProfile? = null
)
