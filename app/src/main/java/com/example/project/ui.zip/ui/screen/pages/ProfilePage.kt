package com.example.project.ui.screen.main.pages

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.project.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilePage(
    paddingValues: PaddingValues,
    onNavigateToSaved: () -> Unit,
    onNavigateToMessages: () -> Unit,
    onLogout: () -> Unit,
    viewModel: ProfileViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.initialize(null) // TODO: Pasar token real
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .verticalScroll(rememberScrollState())
    ) {
        // Header con avatar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(UptelBlue.copy(alpha = 0.1f))
                .padding(Dimens.PaddingLarge),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.size(100.dp),
                shape = CircleShape,
                color = UptelBlue
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = uiState.profile?.name?.first()?.uppercase() ?: "U",
                        style = MaterialTheme.typography.displayMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

            Text(
                text = uiState.profile?.name ?: "Usuario",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = uiState.profile?.email ?: "email@ejemplo.com",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(Dimens.SpacerSmall))

            Surface(
                color = UptelBlue,
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = uiState.profile?.accountType ?: "Usuario",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Estadísticas
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Dimens.PaddingMedium),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            StatCard(
                value = uiState.profile?.propertiesCount?.toString() ?: "0",
                label = "Propiedades"
            )
            StatCard(
                value = uiState.profile?.favoritesCount?.toString() ?: "0",
                label = "Favoritos"
            )
            StatCard(
                value = "0", // TODO: Agregar en backend
                label = "Mensajes"
            )
        }

        Divider(modifier = Modifier.padding(vertical = Dimens.SpacerSmall))

        // Opciones de menú
        ProfileMenuItem(
            icon = Icons.Outlined.Person,
            title = "Editar Perfil",
            onClick = { /* TODO */ }
        )

        ProfileMenuItem(
            icon = Icons.Outlined.BookmarkBorder,
            title = "Mis Favoritos",
            onClick = onNavigateToSaved
        )

        ProfileMenuItem(
            icon = Icons.Outlined.ChatBubbleOutline,
            title = "Mensajes",
            onClick = onNavigateToMessages
        )

        ProfileMenuItem(
            icon = Icons.Outlined.Notifications,
            title = "Notificaciones",
            onClick = { /* TODO */ }
        )

        ProfileMenuItem(
            icon = Icons.Outlined.Settings,
            title = "Configuración",
            onClick = { /* TODO */ }
        )

        ProfileMenuItem(
            icon = Icons.Outlined.Help,
            title = "Ayuda y Soporte",
            onClick = { /* TODO */ }
        )

        Divider(modifier = Modifier.padding(vertical = Dimens.SpacerSmall))

        ProfileMenuItem(
            icon = Icons.Outlined.ExitToApp,
            title = "Cerrar Sesión",
            onClick = onLogout,
            isDestructive = true
        )

        Spacer(modifier = Modifier.height(Dimens.PaddingLarge))
    }

    if (uiState.isLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = UptelBlue)
        }
    }
}

@Composable
private fun StatCard(
    value: String,
    label: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = UptelBlue
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    isDestructive: Boolean = false
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.PaddingMedium, vertical = Dimens.SpacerMedium),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isDestructive) ErrorRed else MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isDestructive) ErrorRed else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            Icon(
                Icons.Outlined.ChevronRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}
