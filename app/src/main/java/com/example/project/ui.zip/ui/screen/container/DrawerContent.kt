package com.example.project.ui.screen.container

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.project.R
import com.example.project.domain.model.User
import com.example.project.ui.theme.Dimens
import com.example.project.ui.theme.ErrorRed
import com.example.project.ui.theme.TextSecondary
import com.example.project.ui.theme.UptelBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawerContent(
    isUserLoggedIn: Boolean,
    currentUser: User?,
    onNavigateTo: (route: String) -> Unit,
    onCloseDrawer: () -> Unit,
    onLogout: () -> Unit
) {
    // Estado para rastrear la ruta seleccionada
    var selectedRoute by rememberSaveable { mutableStateOf(NavGraph.Home.route) }

    ModalDrawerSheet(
        modifier = Modifier.fillMaxWidth(0.85f),
        drawerContainerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // ========================================
            // ENCABEZADO DEL DRAWER
            // ========================================
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = UptelBlue.copy(alpha = 0.1f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(Dimens.PaddingMedium),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo
                    Image(
                        painter = painterResource(id = R.drawable.baseline_warehouse_24),
                        contentDescription = "Logo UPTEL",
                        modifier = Modifier.height(32.dp),
                        contentScale = ContentScale.Fit
                    )

                    // Botón cerrar
                    IconButton(onClick = onCloseDrawer) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Cerrar menú",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(Dimens.SpacerSmall))

            // ========================================
            // PERFIL DEL USUARIO (Si está logueado)
            // ========================================
            if (isUserLoggedIn && currentUser != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Dimens.PaddingMedium),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.padding(Dimens.PaddingMedium),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Avatar
                        Surface(
                            modifier = Modifier.size(48.dp),
                            shape = CircleShape,
                            color = UptelBlue
                        ) {
                            Box(
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = currentUser.name.firstOrNull()?.uppercase() ?: "U",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Info del usuario
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = currentUser.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = currentUser.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = UptelBlue.copy(alpha = 0.2f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = currentUser.accountType,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = UptelBlue,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))
            }

            Divider()

            // ========================================
            // CONTENIDO DEL MENÚ
            // ========================================
            if (isUserLoggedIn) {
                // --- MENÚ DE USUARIO LOGUEADO ---

                DrawerSection(title = "Principal")

                DrawerItem(
                    label = "Inicio",
                    icon = Icons.Outlined.Home,
                    isSelected = selectedRoute == NavGraph.Home.route,
                    onClick = {
                        selectedRoute = NavGraph.Home.route
                        onNavigateTo(NavGraph.Home.route)
                    }
                )

                DrawerItem(
                    label = "Buscar",
                    icon = Icons.Outlined.Search,
                    isSelected = selectedRoute == NavGraph.Search.route,
                    onClick = {
                        selectedRoute = NavGraph.Search.route
                        onNavigateTo(NavGraph.Home.route) // Temporalmente va a Home
                    }
                )

                DrawerItem(
                    label = "Guardados",
                    icon = Icons.Outlined.BookmarkBorder,
                    isSelected = selectedRoute == NavGraph.Saved.route,
                    onClick = {
                        selectedRoute = NavGraph.Saved.route
                        onNavigateTo(NavGraph.Home.route) // Temporalmente va a Home
                    }
                )

                DrawerSection(title = "Tu Cuenta")

                DrawerItem(
                    label = "Mi Perfil",
                    icon = Icons.Outlined.Person,
                    isSelected = selectedRoute == NavGraph.Profile.route,
                    onClick = {
                        selectedRoute = NavGraph.Profile.route
                        onNavigateTo(NavGraph.Profile.route)
                    }
                )

                DrawerItem(
                    label = "Mensajes",
                    icon = Icons.Outlined.ChatBubbleOutline,
                    isSelected = selectedRoute == NavGraph.Messages.route,
                    onClick = {
                        selectedRoute = NavGraph.Messages.route
                        onNavigateTo(NavGraph.Messages.route)
                    }
                )

                DrawerItem(
                    label = "Notificaciones",
                    icon = Icons.Outlined.Notifications,
                    isSelected = selectedRoute == NavGraph.Notifications.route,
                    badgeCount = 2, // Puedes hacerlo dinámico después
                    onClick = {
                        selectedRoute = NavGraph.Notifications.route
                        onNavigateTo(NavGraph.Notifications.route)
                    }
                )

                DrawerSection(title = "Configuración")

                DrawerItem(
                    label = "Ajustes",
                    icon = Icons.Outlined.Settings,
                    isSelected = false,
                    onClick = {
                        // TODO: Crear pantalla de ajustes
                    }
                )

            } else {
                // --- MENÚ DE INVITADO ---

                DrawerSection(title = "Bienvenido")

                DrawerItem(
                    label = "Iniciar Sesión",
                    icon = Icons.Outlined.Login,
                    isSelected = selectedRoute == NavGraph.Login.route,
                    onClick = {
                        selectedRoute = NavGraph.Login.route
                        onNavigateTo(NavGraph.Login.route)
                    }
                )

                DrawerItem(
                    label = "Registrarse",
                    icon = Icons.Outlined.AppRegistration,
                    isSelected = selectedRoute == NavGraph.Register.route,
                    onClick = {
                        selectedRoute = NavGraph.Register.route
                        onNavigateTo(NavGraph.Register.route)
                    }
                )
            }

            // --- INFORMACIÓN (Común para todos) ---

            DrawerSection(title = "Información")

            DrawerItem(
                label = "Acerca de",
                icon = Icons.Outlined.Info,
                isSelected = selectedRoute == NavGraph.About.route,
                onClick = {
                    selectedRoute = NavGraph.About.route
                    onNavigateTo(NavGraph.About.route)
                }
            )

            DrawerItem(
                label = "Cómo Funciona",
                icon = Icons.Outlined.HelpOutline,
                isSelected = selectedRoute == NavGraph.HowItWorks.route,
                onClick = {
                    selectedRoute = NavGraph.HowItWorks.route
                    onNavigateTo(NavGraph.HowItWorks.route)
                }
            )

            DrawerItem(
                label = "Contacto",
                icon = Icons.Outlined.Email,
                isSelected = selectedRoute == NavGraph.Contact.route,
                onClick = {
                    selectedRoute = NavGraph.Contact.route
                    onNavigateTo(NavGraph.Contact.route)
                }
            )

            // ========================================
            // FOOTER: CERRAR SESIÓN
            // ========================================
            Spacer(modifier = Modifier.weight(1f))

            if (isUserLoggedIn) {
                Divider()

                NavigationDrawerItem(
                    label = {
                        Text(
                            "Cerrar Sesión",
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    icon = {
                        Icon(
                            Icons.Default.Logout,
                            contentDescription = null
                        )
                    },
                    selected = false,
                    onClick = onLogout,
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedIconColor = ErrorRed,
                        unselectedTextColor = ErrorRed
                    ),
                    modifier = Modifier.padding(horizontal = Dimens.PaddingMedium, vertical = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(Dimens.SpacerSmall))
        }
    }
}

// ========================================
// COMPONENTES INTERNOS
// ========================================

@Composable
private fun DrawerSection(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = TextSecondary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(
            horizontal = Dimens.PaddingMedium,
            vertical = Dimens.SpacerSmall
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DrawerItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    badgeCount: Int? = null
) {
    NavigationDrawerItem(
        label = {
            Text(
                label,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        icon = {
            Icon(icon, contentDescription = null)
        },
        selected = isSelected,
        onClick = onClick,
        badge = {
            if (badgeCount != null && badgeCount > 0) {
                Badge(
                    containerColor = ErrorRed
                ) {
                    Text(
                        badgeCount.toString(),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        },
        modifier = Modifier.padding(horizontal = Dimens.PaddingMedium, vertical = 2.dp)
    )
}
