package com.example.project.ui.screen.register

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.project.R
import com.example.project.domain.model.User
import com.example.project.ui.components.Input
import com.example.project.ui.components.PrimaryButton
import com.example.project.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    onOpenDrawer: () -> Unit = {},
    onNavigateToLogin: () -> Unit = {},
    onNavigateToTerms: () -> Unit = {},
    onNavigateToPrivacy: () -> Unit = {},
    onRegisterSuccess: (String, User) -> Unit = { _, _ -> }, // ← AÑADIDO: recibe token y user
    viewModel: RegisterViewModel = viewModel()
) {
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirmPassword by rememberSaveable { mutableStateOf("") }
    var accountType by rememberSaveable { mutableStateOf("Estudiante") }
    var acceptedTerms by rememberSaveable { mutableStateOf(false) }

    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var confirmPasswordVisible by rememberSaveable { mutableStateOf(false) }
    var showAccountTypeDialog by remember { mutableStateOf(false) }

    var nameError by rememberSaveable { mutableStateOf<String?>(null) }
    var emailError by rememberSaveable { mutableStateOf<String?>(null) }
    var phoneError by rememberSaveable { mutableStateOf<String?>(null) }
    var passwordError by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmPasswordError by rememberSaveable { mutableStateOf<String?>(null) }

    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val scale = remember { Animatable(0.8f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        scale.animateTo(1f, tween(600, easing = EaseOutBack))
        alpha.animateTo(1f, tween(400))
    }

    // ← MODIFICADO: Solo mostrar errores, NO navegar aquí
    LaunchedEffect(uiState) {
        when (val state = uiState) {
            is RegisterUiState.Error -> {
                snackbarHostState.showSnackbar(
                    message = state.message,
                    duration = SnackbarDuration.Short
                )
                viewModel.resetState()
            }
            else -> {}
        }
    }

    if (showAccountTypeDialog) {
        AlertDialog(
            onDismissRequest = { showAccountTypeDialog = false },
            title = { Text("Selecciona tipo de cuenta") },
            text = {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = accountType == "Estudiante",
                            onClick = { accountType = "Estudiante" }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Estudiante")
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = accountType == "Propietario",
                            onClick = { accountType = "Propietario" }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Propietario")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountTypeDialog = false }) {
                    Text("Aceptar")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.baseline_warehouse_24),
                        contentDescription = "Logo UPTEL",
                        modifier = Modifier.height(32.dp),
                        contentScale = ContentScale.Fit
                    )
                },
                actions = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Menú")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(appBackgroundGradient)
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = Dimens.PaddingMedium)
                    .scale(scale.value)
                    .alpha(alpha.value),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

                Image(
                    painter = painterResource(id = R.drawable.ou),
                    contentDescription = "Ilustración de Registro",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentScale = ContentScale.Fit
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

                Text(
                    text = "Crear Cuenta",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerSmall))

                Text(
                    text = "Únete a la comunidad de UPTEL",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

                Input(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = null
                    },
                    label = "Nombre completo",
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null)
                    },
                    isError = nameError != null,
                    errorMessage = nameError
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                Input(
                    value = email,
                    onValueChange = {
                        email = it
                        emailError = null
                    },
                    label = "Correo electrónico",
                    leadingIcon = {
                        Icon(Icons.Default.Email, contentDescription = null)
                    },
                    isError = emailError != null,
                    errorMessage = emailError
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                Input(
                    value = phone,
                    onValueChange = {
                        phone = it
                        phoneError = null
                    },
                    label = "Teléfono (opcional)",
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null)
                    },
                    isError = phoneError != null,
                    errorMessage = phoneError
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                Input(
                    value = password,
                    onValueChange = {
                        password = it
                        passwordError = null
                    },
                    label = "Contraseña",
                    visualTransformation = if (passwordVisible)
                        VisualTransformation.None else PasswordVisualTransformation(),
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Filled.VisibilityOff
                                else Icons.Filled.Visibility,
                                "Toggle password"
                            )
                        }
                    },
                    isError = passwordError != null,
                    errorMessage = passwordError
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                Input(
                    value = confirmPassword,
                    onValueChange = {
                        confirmPassword = it
                        confirmPasswordError = null
                    },
                    label = "Confirmar contraseña",
                    visualTransformation = if (confirmPasswordVisible)
                        VisualTransformation.None else PasswordVisualTransformation(),
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                            Icon(
                                if (confirmPasswordVisible) Icons.Filled.VisibilityOff
                                else Icons.Filled.Visibility,
                                "Toggle password"
                            )
                        }
                    },
                    isError = confirmPasswordError != null,
                    errorMessage = confirmPasswordError
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                OutlinedButton(
                    onClick = { showAccountTypeDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        if (accountType == "Estudiante") Icons.Default.School
                        else Icons.Default.Home,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Tipo de cuenta: $accountType")
                }

                Spacer(modifier = Modifier.height(Dimens.SpacerMedium))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = acceptedTerms,
                        onCheckedChange = { acceptedTerms = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Acepto los términos y condiciones",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

                // ← MODIFICADO: Botón ahora llama al callback con token y user
                PrimaryButton(
                    text = if (uiState is RegisterUiState.Loading)
                        "Registrando..." else "Registrarse",
                    onClick = {
                        var hasErrors = false

                        if (name.isBlank()) {
                            nameError = "El nombre es requerido"
                            hasErrors = true
                        }
                        if (email.isBlank()) {
                            emailError = "El correo es requerido"
                            hasErrors = true
                        }
                        if (password.length < 8) {
                            passwordError = "La contraseña debe tener al menos 8 caracteres"
                            hasErrors = true
                        }
                        if (password != confirmPassword) {
                            confirmPasswordError = "Las contraseñas no coinciden"
                            hasErrors = true
                        }
                        if (!acceptedTerms) {
                            hasErrors = true
                        }

                        if (!hasErrors) {
                            // ← CAMBIO: Agregado confirmPassword
                            viewModel.register(
                                name = name,
                                email = email,
                                password = password,
                                confirmPassword = confirmPassword, // ← AÑADIDO
                                accountType = accountType,
                                onSuccess = { token, user ->
                                    // Este lambda se ejecuta SOLO si el backend respondió OK
                                    onRegisterSuccess(token, user)
                                }
                            )
                        }
                    },
                    enabled = uiState !is RegisterUiState.Loading && acceptedTerms
                )

                Spacer(modifier = Modifier.height(Dimens.SpacerLarge))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "¿Ya tienes cuenta? ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    TextButton(
                        onClick = onNavigateToLogin,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "Inicia sesión",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = UptelBlue
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(Dimens.PaddingMedium))
            }

            if (uiState is RegisterUiState.Loading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(60.dp),
                        strokeWidth = 6.dp,
                        color = UptelBlue
                    )
                }
            }
        }
    }
}
