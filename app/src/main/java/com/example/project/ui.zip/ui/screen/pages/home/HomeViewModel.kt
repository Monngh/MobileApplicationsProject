package com.example.project.ui.screen.pages.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.data.remote.RetrofitClient
import com.example.project.data.repository.PropertyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(
    private val propertyRepository: PropertyRepository = RetrofitClient.createPropertyRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    // Token (se debe pasar desde AuthViewModel)
    private var authToken: String? = null

    init {
        // No cargamos automáticamente, esperamos el token
    }

    /**
     * Inicializar con token del AuthViewModel
     */
    fun initialize(token: String?) {
        authToken = token
        if (token != null) {
            loadProperties()
        } else {
            // Mostrar datos mock si no hay token (modo offline)
            loadMockProperties()
        }
    }

    /**
     * Cargar propiedades desde la API
     */
    fun loadProperties() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            if (authToken != null) {
                val result = propertyRepository.getProperties(authToken!!)

                if (result.isSuccess) {
                    val properties = result.getOrNull() ?: emptyList()
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        properties = properties,
                        featured = properties.filter { it.isVerified }.take(5)
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message
                    )
                }
            } else {
                loadMockProperties()
            }
        }
    }

    /**
     * Cargar propiedades mock (para pruebas sin backend)
     */
    private fun loadMockProperties() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            kotlinx.coroutines.delay(1000)

            val mockProperties = generateMockProperties()
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                properties = mockProperties,
                featured = mockProperties.take(5)
            )
        }
    }

    fun onSearchTextChanged(text: String) {
        _uiState.value = _uiState.value.copy(searchText = text)
        filterProperties()
    }

    fun onCategorySelected(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
        filterProperties()
    }

    fun toggleFavorite(propertyId: String) {
        val updatedProperties = _uiState.value.properties.map {
            if (it.id == propertyId) it.copy(isFavorite = !it.isFavorite) else it
        }

        val updatedFeatured = _uiState.value.featured.map {
            if (it.id == propertyId) it.copy(isFavorite = !it.isFavorite) else it
        }

        _uiState.value = _uiState.value.copy(
            properties = updatedProperties,
            featured = updatedFeatured
        )

        // TODO: Sincronizar con API
        // viewModelScope.launch {
        //     if (updatedProperties.find { it.id == propertyId }?.isFavorite == true) {
        //         favoriteRepository.addToFavorites(authToken!!, propertyId)
        //     } else {
        //         favoriteRepository.removeFromFavorites(authToken!!, propertyId)
        //     }
        // }
    }

    private fun filterProperties() {
        loadProperties()
    }

    private fun generateMockProperties(): List<PropertyItem> {
        return listOf(
            PropertyItem("1", "Departamento Moderno Centro", "Centro, SLP", "5,500", 4.8f, 2, 1, true, false),
            PropertyItem("2", "Casa Amplia Lomas", "Lomas, SLP", "8,200", 4.9f, 3, 2, true, false),
            PropertyItem("3", "Estudio Amueblado UPTEL", "Cerca UPTEL", "3,800", 4.5f, 1, 1, false, false),
            PropertyItem("4", "Departamento Vista Panorámica", "Tangamanga, SLP", "6,500", 4.7f, 2, 2, true, false),
            PropertyItem("5", "Casa Residencial Privada", "Privada del Pedregal", "12,000", 5.0f, 4, 3, true, false),
            PropertyItem("6", "Loft Industrial Universitario", "Zona Universitaria", "4,200", 4.3f, 1, 1, false, false),
            PropertyItem("7", "Penthouse Exclusivo", "Lomas 4a Secc", "15,000", 4.9f, 3, 3, true, false),
            PropertyItem("8", "Departamento Familiar", "Himno Nacional", "7,500", 4.6f, 3, 2, false, false)
        )
    }
}

data class HomeUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val properties: List<PropertyItem> = emptyList(),
    val featured: List<PropertyItem> = emptyList(),
    val searchText: String = "",
    val selectedCategory: String = "Todos"
)

data class PropertyItem(
    val id: String,
    val title: String,
    val location: String,
    val price: String,
    val rating: Float,
    val beds: Int,
    val baths: Int,
    val isVerified: Boolean,
    val isFavorite: Boolean
)
