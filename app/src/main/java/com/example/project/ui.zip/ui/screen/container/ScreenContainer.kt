package com.example.project.ui.screen.container

import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.project.ui.screen.about.AboutScreen
import com.example.project.ui.screen.chat_detail.ChatDetailScreen
import com.example.project.ui.screen.contact.ContactScreen
import com.example.project.ui.screen.detail.PropertyDetailPage
import com.example.project.ui.screen.forgot_password.ForgotPasswordScreen
import com.example.project.ui.screen.how_it_works.HowItWorksScreen
import com.example.project.ui.screen.login.LoginScreen
import com.example.project.ui.screen.login.LoginViewModel
import com.example.project.ui.screen.main.MainScreen
import com.example.project.ui.screen.main.pages.NotificationPage
import com.example.project.ui.screen.pages.home.HomeViewModel
import com.example.project.ui.screen.register.RegisterScreen
import com.example.project.ui.screen.register.RegisterViewModel
import com.example.project.ui.screen.welcome.WelcomeScreen
import kotlinx.coroutines.launch

@Composable
fun ScreenContainer() {
    val navController = rememberNavController()

    // AuthViewModel - Gestión Global de Autenticación
    val authViewModel: AuthViewModel = viewModel()
    val authState by authViewModel.authState.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()

    // Estados del Drawer
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Funciones de Control
    val onOpenDrawer: () -> Unit = {
        scope.launch { drawerState.open() }
    }

    val onCloseDrawer: () -> Unit = {
        scope.launch { drawerState.close() }
    }

    val onNavigateTo: (String) -> Unit = { route ->
        navController.navigate(route) {
            launchSingleTop = true
        }
        onCloseDrawer()
    }

    val onLogout: () -> Unit = {
        authViewModel.logout()
        navController.navigate(NavGraph.Welcome.route) {
            popUpTo(0) { inclusive = true }
        }
        onCloseDrawer()
    }

    // UI Principal
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(
                isUserLoggedIn = authViewModel.isLoggedIn(),
                currentUser = currentUser,
                onNavigateTo = onNavigateTo,
                onCloseDrawer = onCloseDrawer,
                onLogout = onLogout
            )
        }
    ) {
        NavHost(
            navController = navController,
            startDestination = when (authState) {
                is AuthState.Authenticated -> NavGraph.Home.route
                is AuthState.Unauthenticated -> NavGraph.Welcome.route
                is AuthState.Checking -> NavGraph.Welcome.route
            }
        ) {
            // ========================================
            // PANTALLAS DE AUTENTICACIÓN
            // ========================================

            composable(NavGraph.Welcome.route) {
                WelcomeScreen(
                    onNavigateToRegister = {
                        navController.navigate(NavGraph.Register.route)
                    },
                    onNavigateToLogin = {
                        navController.navigate(NavGraph.Login.route)
                    }
                )
            }

            composable(NavGraph.Login.route) {
                val loginViewModel: LoginViewModel = viewModel()

                LoginScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateToForgotPassword = {
                        navController.navigate(NavGraph.ForgotPassword.route)
                    },
                    onNavigateToRegister = {
                        navController.navigate(NavGraph.Register.route)
                    },
                    onLoginSuccess = { token, user ->
                        // AQUÍ conectamos login con AuthViewModel y navegamos
                        authViewModel.onLoginSuccess(token, user)
                        navController.navigate(NavGraph.Home.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    viewModel = loginViewModel
                )
            }


            composable(NavGraph.Register.route) {
                val registerViewModel: RegisterViewModel = viewModel()

                RegisterScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateToLogin = {
                        navController.navigate(NavGraph.Login.route)
                    },
                    onNavigateToTerms = { /* TODO */ },
                    onNavigateToPrivacy = { /* TODO */ },
                    onRegisterSuccess = { token, user ->
                        authViewModel.onLoginSuccess(token, user)
                        navController.navigate(NavGraph.Home.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    viewModel = registerViewModel
                )
            }



            composable(NavGraph.ForgotPassword.route) {
                ForgotPasswordScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }

            // ========================================
            // PANTALLAS PRINCIPALES
            // ========================================

            composable(NavGraph.Home.route) {
                val homeViewModel: HomeViewModel = viewModel()

                // Inicializar HomeViewModel con el token
                LaunchedEffect(Unit) {
                    homeViewModel.initialize(authViewModel.getToken())
                }

                MainScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateToChatDetail = { chatId ->
                        navController.navigate("${NavGraph.ChatDetail.route}/$chatId")
                    },
                    onNavigateToPropertyDetail = { propertyId ->
                        navController.navigate("${NavGraph.PropertyDetail.route}/$propertyId")
                    },
                    onLogout = onLogout
                )
            }

            composable(NavGraph.Profile.route) {
                MainScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateToChatDetail = { chatId ->
                        navController.navigate("${NavGraph.ChatDetail.route}/$chatId")
                    },
                    onNavigateToPropertyDetail = { propertyId ->
                        navController.navigate("${NavGraph.PropertyDetail.route}/$propertyId")
                    },
                    onLogout = onLogout,
                    startDestination = NavGraph.Profile.route
                )
            }

            composable(NavGraph.Messages.route) {
                MainScreen(
                    onOpenDrawer = onOpenDrawer,
                    onNavigateToChatDetail = { chatId ->
                        navController.navigate("${NavGraph.ChatDetail.route}/$chatId")
                    },
                    onNavigateToPropertyDetail = { propertyId ->
                        navController.navigate("${NavGraph.PropertyDetail.route}/$propertyId")
                    },
                    onLogout = onLogout,
                    startDestination = NavGraph.Messages.route
                )
            }

            // ========================================
            // PANTALLAS DE DETALLE
            // ========================================

            composable(
                route = "${NavGraph.PropertyDetail.route}/{propertyId}",
                arguments = listOf(navArgument("propertyId") { type = NavType.StringType })
            ) {
                PropertyDetailPage(
                    onNavigateBack = { navController.popBackStack() },
                    onCallOwner = { /* TODO */ },
                    onMessageOwner = { /* TODO */ }
                )
            }

            composable(
                route = "${NavGraph.ChatDetail.route}/{chatId}",
                arguments = listOf(navArgument("chatId") { type = NavType.StringType })
            ) { backStackEntry ->
                val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
                ChatDetailScreen(
                    chatId = chatId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // ========================================
            // PANTALLAS DE INFORMACIÓN
            // ========================================

            composable(NavGraph.Notifications.route) {
                NotificationPage(
                    onOpenDrawer = onOpenDrawer
                )
            }

            composable(NavGraph.About.route) {
                AboutScreen(
                    onOpenDrawer = onOpenDrawer
                )
            }

            composable(NavGraph.HowItWorks.route) {
                HowItWorksScreen(
                    onOpenDrawer = onOpenDrawer
                )
            }

            composable(NavGraph.Contact.route) {
                ContactScreen(
                    onOpenDrawer = onOpenDrawer
                )
            }
        }
    }
}
