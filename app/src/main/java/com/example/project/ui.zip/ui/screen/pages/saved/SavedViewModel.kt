package com.example.project.ui.screen.pages.saved

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.data.remote.RetrofitClient
import com.example.project.data.repository.FavoriteRepository
import com.example.project.ui.screen.pages.home.PropertyItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SavedViewModel(
    private val favoriteRepository: FavoriteRepository = RetrofitClient.createFavoriteRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(SavedUiState())
    val uiState: StateFlow<SavedUiState> = _uiState.asStateFlow()

    private var authToken: String? = null

    fun initialize(token: String?) {
        authToken = token
        if (token != null) {
            loadFavorites()
        } else {
            loadMockFavorites()
        }
    }

    fun loadFavorites() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            if (authToken != null) {
                val result = favoriteRepository.getFavorites(authToken!!)

                if (result.isSuccess) {
                    val favorites = result.getOrNull() ?: emptyList()
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        favorites = favorites
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message
                    )
                }
            } else {
                loadMockFavorites()
            }
        }
    }

    fun removeFromFavorites(propertyId: String) {
        viewModelScope.launch {
            val updatedFavorites = _uiState.value.favorites.filter { it.id != propertyId }
            _uiState.value = _uiState.value.copy(favorites = updatedFavorites)

            // Llamar a API
            authToken?.let { token ->
                favoriteRepository.removeFromFavorites(token, propertyId)
            }
        }
    }

    fun onCategorySelected(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
        filterFavorites()
    }

    private fun filterFavorites() {
        // TODO: Implementar filtrado por categoría
        loadFavorites()
    }

    private fun loadMockFavorites() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            kotlinx.coroutines.delay(1000)

            val mockFavorites = listOf(
                PropertyItem("1", "Departamento Moderno Centro", "Centro, SLP", "5,500", 4.8f, 2, 1, true, true),
                PropertyItem("4", "Departamento Vista Panorámica", "Tangamanga, SLP", "6,500", 4.7f, 2, 2, true, true)
            )

            _uiState.value = _uiState.value.copy(
                isLoading = false,
                favorites = mockFavorites
            )
        }
    }
}

data class SavedUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val favorites: List<PropertyItem> = emptyList(),
    val selectedCategory: String = "Todos"
)
